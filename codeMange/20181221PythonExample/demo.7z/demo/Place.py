class Place:
    # def setNameCn(self, name):
    #     self.name = name
    #
    # def setCode(self, code):
    #     self.code = code
    #
    # def setUrl(self, url):
    #     self.url = url

    nameCn = ""
    code = ""
    url = ""
    list = []
